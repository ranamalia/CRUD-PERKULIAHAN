<?php
class BaseController {
    protected function loadView($view, $data = []) {
        // Extract data array to variables
        extract($data);
        
        // Include header
        include 'views/layouts/header.php';
        
        // Include sidebar
        include 'views/layouts/sidebar.php';
        
        // Include main content
        include "views/$view.php";
        
        // Include footer
        include 'views/layouts/footer.php';
    }
    
    protected function redirect($url) {
        header("Location: " . BASE_URL . $url);
        exit();
    }
    
    protected function jsonResponse($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit();
    }
}
?>
