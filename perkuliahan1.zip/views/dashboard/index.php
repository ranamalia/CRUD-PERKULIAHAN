<div class="content">
    <div class="page-header">
        <h1>Dashboard Sistem Perkuliahan</h1>
        <p>Selamat datang di Sistem Informasi Perkuliahan</p>
    </div>
    
    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card primary">
            <div class="stat-number"><?php echo $totalMhs; ?></div>
            <div class="stat-label">Total Mahasiswa</div>
        </div>
        
        <div class="stat-card secondary">
            <div class="stat-number"><?php echo $totalDosen; ?></div>
            <div class="stat-label">Total Dosen</div>
        </div>
        
        <div class="stat-card primary">
            <div class="stat-number"><?php echo $totalMataKuliah; ?></div>
            <div class="stat-label">Total Mata Kuliah</div>
        </div>
        
        <div class="stat-card secondary">
            <div class="stat-number"><?php echo $totalKuliah; ?></div>
            <div class="stat-label">Total Data Kuliah</div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Menu Utama</h3>
        </div>
        
        <div class="quick-actions">
            <div class="action-grid">
                <a href="<?php echo BASE_URL; ?>mhs" class="action-card">
                    <div class="action-icon">👨‍🎓</div>
                    <h4>Data Mahasiswa</h4>
                    <p>Kelola data mahasiswa, tambah, edit, dan hapus data mahasiswa</p>
                </a>
                
                <a href="<?php echo BASE_URL; ?>dosen" class="action-card">
                    <div class="action-icon">👨‍🏫</div>
                    <h4>Data Dosen</h4>
                    <p>Kelola data dosen pengajar mata kuliah</p>
                </a>
                
                <a href="<?php echo BASE_URL; ?>matakuliah" class="action-card">
                    <div class="action-icon">📚</div>
                    <h4>Data Mata Kuliah</h4>
                    <p>Kelola mata kuliah yang tersedia</p>
                </a>
                
                <a href="<?php echo BASE_URL; ?>kuliah" class="action-card">
                    <div class="action-icon">📊</div>
                    <h4>Data Kuliah</h4>
                    <p>Kelola data kuliah dan nilai mahasiswa</p>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Informasi Sistem</h3>
        </div>
        
        <div class="info-grid">
            <div class="info-item">
                <h4>Fitur Sistem</h4>
                <ul>
                    <li>✅ CRUD Data Mahasiswa</li>
                    <li>✅ CRUD Data Dosen</li>
                    <li>✅ CRUD Data Mata Kuliah</li>
                    <li>✅ CRUD Data Kuliah & Nilai</li>
                    <li>✅ Validasi Data Input</li>
                    <li>✅ Relasi Antar Tabel</li>
                </ul>
            </div>
            
            <div class="info-item">
                <h4>Teknologi yang Digunakan</h4>
                <ul>
                    <li>🔧 PHP Native dengan MVC Pattern</li>
                    <li>🗄️ MySQL Database</li>
                    <li>🎨 CSS Custom dengan Font Poppins</li>
                    <li>📱 Responsive Design</li>
                    <li>🔒 Data Validation & Security</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<style>
.quick-actions {
    padding: 20px 0;
}

.action-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.action-card {
    background-color: white;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    padding: 25px;
    text-decoration: none;
    color: #333;
    transition: all 0.3s;
    text-align: center;
}

.action-card:hover {
    border-color: #94C2DA;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(148, 194, 218, 0.3);
}

.action-icon {
    font-size: 3rem;
    margin-bottom: 15px;
}

.action-card h4 {
    color: #94C2DA;
    margin-bottom: 10px;
    font-weight: 600;
}

.action-card p {
    color: #666;
    font-size: 0.9rem;
    line-height: 1.4;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    padding: 20px 0;
}

.info-item h4 {
    color: #94C2DA;
    margin-bottom: 15px;
    font-weight: 600;
}

.info-item ul {
    list-style: none;
    padding: 0;
}

.info-item li {
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f0;
    font-size: 0.9rem;
}

.info-item li:last-child {
    border-bottom: none;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .action-grid {
        grid-template-columns: 1fr;
    }
    
    .info-grid {
        grid-template-columns: 1fr;
    }
}
</style>
