<footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Dibuat dengan PHP MVC.</p>
    </footer>
</div> <!-- End main-content -->
</div> <!-- End container -->
</body>
</html>
